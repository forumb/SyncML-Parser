package com.example.syncmlparser;

public class Target {
    public String LocUri;

    public String getLocUri() {
        return LocUri;
    }

    public void setLocUri(String locUri) {
        LocUri = locUri;
    }
}

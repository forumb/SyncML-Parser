package com.example.syncmlparser;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.xmlpull.v1.XmlSerializer;
import android.util.Log;
import android.util.Xml;


public class CreateXML {

 //       File newxmlfile = new File("D:\new.xml");
        SyncML syncML;


        public void xmlmethod() {

            File newxmlfile = new File("/data/new.xml");
            Log.d("Hii", "You are here!!!");

            try {
                newxmlfile.createNewFile();
            } catch (IOException exc) {
                exc.printStackTrace();
            }


            FileOutputStream fileos = null;

            try {
                fileos = new FileOutputStream(newxmlfile);
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }


            XmlSerializer serializer = Xml.newSerializer();
            try {


                serializer.setOutput(fileos, "UTF-8");
                serializer.startDocument(null, Boolean.valueOf(true));
                serializer.setFeature("http://xmlpull.org/v1/doc/features.html#indent-output", true);
                serializer.startTag(null, "root");
                serializer.startTag(null, "Child1");
                serializer.endTag(null, "Child1");
                serializer.startTag(null, "Child2");
                serializer.attribute(null, "attribute", "value");
                serializer.endTag(null, "Child2");
                serializer.startTag(null, "Child3");
                serializer.text("Some text inside child 3");
                serializer.endTag(null, "Child3");
                serializer.endTag(null, "root");
                serializer.endDocument();
                serializer.flush();
                fileos.close();
                //TextView tv = (TextView)findViewById(R.);

            } catch (Exception e) {
                Log.e("Exception", "Exception occured in writing");
            }
        }
    }

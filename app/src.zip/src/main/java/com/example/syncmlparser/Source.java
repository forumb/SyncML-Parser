package com.example.syncmlparser;

public class Source {
    public String LocUri;

    public String getLocUri() {
        return LocUri;
    }

    public void setLocUri(String locUri) {
        LocUri = locUri;
    }
}

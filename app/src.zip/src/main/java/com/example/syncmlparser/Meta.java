package com.example.syncmlparser;

public class Meta {
    public String metaformatattribute;
    public String metaformatvalue;
    public String metatypeattribute;
    public String metatypevalue;
    public String metamaxmsgsizeattribute;
    public String metamaxmsgsizevalue;

    public String getMetamaxmsgsizeattribute() {
        return metamaxmsgsizeattribute;
    }

    public void setMetamaxmsgsizeattribute(String metamaxmsgsizeattribute) {
        this.metamaxmsgsizeattribute = metamaxmsgsizeattribute;
    }

    public String getMetamaxmsgsizevalue() {
        return metamaxmsgsizevalue;
    }

    public void setMetamaxmsgsizevalue(String metamaxmsgsizevalue) {
        this.metamaxmsgsizevalue = metamaxmsgsizevalue;
    }

    public String getMetaformatattribute() {
        return metaformatattribute;
    }

    public String getMetaformatvalue() {
        return metaformatvalue;
    }

    public String getMetatypeattribute() {
        return metatypeattribute;
    }

    public String getMetatypevalue() {
        return metatypevalue;
    }

    public void setMetaformatattribute(String metaformatattribute) {
        this.metaformatattribute = metaformatattribute;
    }

    public void setMetaformatvalue(String metaformatvalue) {
        this.metaformatvalue = metaformatvalue;
    }

    public void setMetatypeattribute(String metatypeattribute) {
        this.metatypeattribute = metatypeattribute;
    }

    public void setMetatypevalue(String metatypevalue) {
        this.metatypevalue = metatypevalue;
    }

}
